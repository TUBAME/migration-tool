Add the following dtd files to this directory.

 - docbook.xsd:
   http://www.docbook.org/xml/5.0/xsd/docbook.xsd

 - xlink.xsd:
   http://www.docbook.org/xml/5.0/xsd/xlink.xsd

 - xml.xsd:
   http://www.docbook.org/xml/5.0/xsd/xml.xsd


[Attention for docbook.xsd]
The difference between the original docbook.xsd file:
- Delete xlink.xsd import
- Delete related tags about xlink
External references to the Internet can not be by it.
