
        (function($) {
            $.fn.KnowhowFactorGraphSumCalclator_graph_getResult = function(options) {
                var result = [{"data": [[0, 0],[0, 40],[1, 40]], "label": "JavaSE/JavaEEバージョンアップに伴う修正"}, {"data": [[0, 0],[1, 0]], "label": "APサーバ非推奨機能に関する修正"}, {"data": [[1, 585]], "label": "APサーバ固有機能に関する修正"}]
                return result;
            };
        })(jQuery);
        