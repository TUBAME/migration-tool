
        (function($) {
            $.fn.FrameworkKnowhowDegreeOfDifficultySumCalclator_fromStrutsFw_getResult = function(options) {
                var result = {'Unknown2': 0, 'High': 0, 'Middle': 14, 'Unknown1': 0, 'Low2': 80, 'Low1': 0}
                return result;
            };
        })(jQuery);
        