
        (function($) {
            $.fn.FrameworkKnowhowFactorSumCalclator_fromStrutsFw_getResult = function(options) {
                var result = {'mvcFrameworkM': 14, 'mvcFrameworkSpecificBackwardCompati': 60, 'mvcFrameworkV': 40, 'mvcFrameworkC': 0, 'mvcFrameworkSpecificNonBackwardCompati': 40}
                return result;
            };
        })(jQuery);
        