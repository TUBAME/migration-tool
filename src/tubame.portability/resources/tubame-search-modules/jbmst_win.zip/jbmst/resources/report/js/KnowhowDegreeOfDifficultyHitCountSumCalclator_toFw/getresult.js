
        (function($) {
            $.fn.KnowhowDegreeOfDifficultyHitCountSumCalclator_toFw_getResult = function(options) {
                var result = {'Unknown2': 0, 'NOT_TRN': 0, 'High': 0, 'Middle': 9, 'Unknown1': 0, 'Low2': 14, 'Low1': 0}
                return result;
            };
        })(jQuery);
        