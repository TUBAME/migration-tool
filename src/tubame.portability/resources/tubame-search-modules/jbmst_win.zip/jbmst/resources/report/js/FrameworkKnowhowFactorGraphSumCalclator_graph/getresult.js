
        (function($) {
            $.fn.FrameworkKnowhowFactorGraphSumCalclator_graph_getResult = function(options) {
                var result = [{"data": [[0, 0],[0, 14],[1, 14]], "label": "Model機能にともなう修正"}, {"data": [[0, 40],[1, 40]], "label": "View機能にともなう修正"}, {"data": [[0, 200],[1, 200]], "label": "Controller機能にともなう修正"},{"data": [[0, 40],[1, 40]], "label": "MVCフレーム独自機能(上位互換なし)の修正"},{"data": [[1, 60]], "label": "MVCフレーム独自機能(上位互換あり)の修正"}]
                return result;
            };
        })(jQuery);
        