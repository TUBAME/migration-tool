
        (function($) {
            $.fn.KnowhowFileCategorySumCalclator_toAp_getResult = function(options) {
                var result = {'xml': 40, 'jsp': 134, 'java': 451, 'properties': 0}
                return result;
            };
        })(jQuery);
        