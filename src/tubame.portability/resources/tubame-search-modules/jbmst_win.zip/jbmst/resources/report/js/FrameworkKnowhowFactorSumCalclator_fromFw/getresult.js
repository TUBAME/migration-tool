
        (function($) {
            $.fn.FrameworkKnowhowFactorSumCalclator_fromFw_getResult = function(options) {
                var result = {'mvcFrameworkM': 14, 'mvcFrameworkSpecificBackwardCompati': 0, 'mvcFrameworkV': 40, 'mvcFrameworkC': 200, 'mvcFrameworkSpecificNonBackwardCompati': 40}
                return result;
            };
        })(jQuery);
        