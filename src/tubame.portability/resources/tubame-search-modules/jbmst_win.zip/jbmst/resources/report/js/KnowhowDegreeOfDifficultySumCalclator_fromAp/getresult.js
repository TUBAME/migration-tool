
        (function($) {
            $.fn.KnowhowDegreeOfDifficultySumCalclator_fromAp_getResult = function(options) {
                var result = {'Unknown2': 0, 'Middle': 0, 'High': 0, 'NOT_TRN': 0, 'Unknown1': 0, 'Low2': 40, 'Low1': 0}
                return result;
            };
        })(jQuery);
        