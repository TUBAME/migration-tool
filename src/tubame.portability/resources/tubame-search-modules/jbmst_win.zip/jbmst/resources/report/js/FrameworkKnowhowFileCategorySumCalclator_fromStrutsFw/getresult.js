
        (function($) {
            $.fn.FrameworkKnowhowFileCategorySumCalclator_fromStrutsFw_getResult = function(options) {
                var result = {'xml': 0, 'jsp': 80, 'java': 14, 'properties': 0}
                return result;
            };
        })(jQuery);
        