
        (function($) {
            $.fn.KnowhowFileCategorySumCalclator_fromAp_getResult = function(options) {
                var result = {'xml': 0, 'jsp': 0, 'java': 40, 'properties': 0}
                return result;
            };
        })(jQuery);
        