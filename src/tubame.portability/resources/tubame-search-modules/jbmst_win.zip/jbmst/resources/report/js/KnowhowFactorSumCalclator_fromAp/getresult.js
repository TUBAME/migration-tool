
        (function($) {
            $.fn.KnowhowFactorSumCalclator_fromAp_getResult = function(options) {
                var result = {'JavaEESpecChange': 40, 'ApServerDependsChange': 0, 'JavaVersionUpgradeChange': 0, 'ApServerDependsDepricatedChange': 0, 'WeblogicSpecChange': 0, 'DBMSChange': 0, 'APlibrary': 0}
                return result;
            };
        })(jQuery);
        