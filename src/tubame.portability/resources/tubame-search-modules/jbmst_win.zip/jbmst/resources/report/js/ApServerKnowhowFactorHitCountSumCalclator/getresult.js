
        (function($) {
            $.fn.ApServerKnowhowFactorHitCountSumCalclator_getResult = function(options) {
                var result = {'ApServerSpecficChange': 399, 'javaAndJavaEESpecChange': 4, 'ApServerDepricatedChange': 0}
                return result;
            };
        })(jQuery);
        