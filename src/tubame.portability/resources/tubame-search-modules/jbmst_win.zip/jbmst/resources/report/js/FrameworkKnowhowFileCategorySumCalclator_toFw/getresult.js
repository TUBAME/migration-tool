
        (function($) {
            $.fn.FrameworkKnowhowFileCategorySumCalclator_toFw_getResult = function(options) {
                var result = {'xml': 0, 'jsp': 140, 'java': 214, 'properties': 0}
                return result;
            };
        })(jQuery);
        