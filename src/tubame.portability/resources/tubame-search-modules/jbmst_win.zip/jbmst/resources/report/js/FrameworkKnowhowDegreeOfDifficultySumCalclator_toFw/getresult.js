
        (function($) {
            $.fn.FrameworkKnowhowDegreeOfDifficultySumCalclator_toFw_getResult = function(options) {
                var result = {'Unknown2': 0, 'High': 0, 'Middle': 214, 'Unknown1': 0, 'Low2': 140, 'Low1': 0}
                return result;
            };
        })(jQuery);
        