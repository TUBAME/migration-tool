
        (function($) {
            $.fn.FrameworkKnowhowFileCategorySumCalclator_fromFw_getResult = function(options) {
                var result = {'xml': 0, 'jsp': 80, 'java': 214, 'properties': 0}
                return result;
            };
        })(jQuery);
        