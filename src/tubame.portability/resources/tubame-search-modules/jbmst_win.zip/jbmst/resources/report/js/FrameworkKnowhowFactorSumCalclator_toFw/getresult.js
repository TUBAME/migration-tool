
        (function($) {
            $.fn.FrameworkKnowhowFactorSumCalclator_toFw_getResult = function(options) {
                var result = {'mvcFrameworkM': 14, 'mvcFrameworkSpecificBackwardCompati': 60, 'mvcFrameworkV': 40, 'mvcFrameworkC': 200, 'mvcFrameworkSpecificNonBackwardCompati': 40}
                return result;
            };
        })(jQuery);
        