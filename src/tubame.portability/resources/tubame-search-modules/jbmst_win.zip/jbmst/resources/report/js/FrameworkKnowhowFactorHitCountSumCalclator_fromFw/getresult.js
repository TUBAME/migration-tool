
        (function($) {
            $.fn.FrameworkKnowhowFactorHitCountSumCalclator_fromFw_getResult = function(options) {
                var result = {'MVCFramework_Controller': 2, 'MVCFrameworkSpecific_NonBackwardCompati': 4, 'MVCFrameworkSpecific_BackwardCompati': 0, 'MVCFramework_Model': 7, 'MVCFramework_View': 4}
                return result;
            };
        })(jQuery);
        