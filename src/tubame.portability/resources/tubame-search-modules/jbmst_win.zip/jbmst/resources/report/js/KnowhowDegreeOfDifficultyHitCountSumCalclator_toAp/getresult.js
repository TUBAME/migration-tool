
        (function($) {
            $.fn.KnowhowDegreeOfDifficultyHitCountSumCalclator_toAp_getResult = function(options) {
                var result = {'Unknown2': 1, 'NOT_TRN': 0, 'High': 0, 'Middle': 14, 'Unknown1': 0, 'Low2': 193, 'Low1': 195}
                return result;
            };
        })(jQuery);
        