
        (function($) {
            $.fn.KnowhowFactorSumCalclator_toAp_getResult = function(options) {
                var result = {'JavaEESpecChange': 40, 'ApServerDependsChange': 515, 'JavaVersionUpgradeChange': 0, 'ApServerDependsDepricatedChange': 0, 'WeblogicSpecChange': 70, 'DBMSChange': 0, 'APlibrary': 0}
                return result;
            };
        })(jQuery);
        