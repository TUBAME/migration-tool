
        (function($) {
            $.fn.KnowhowDegreeOfDifficultyHitCountSumCalclator_fromStrutsFw_getResult = function(options) {
                var result = {'Unknown2': 0, 'NOT_TRN': 0, 'High': 0, 'Middle': 7, 'Unknown1': 0, 'Low2': 14, 'Low1': 0}
                return result;
            };
        })(jQuery);
        